import React from 'react';
import './About.css';
import mapIcon from './images/map-icon.png';
const About = () => {
  return (
    <div className="container">
      <div className="heading">
        <h1><center>ABOUT US</center></h1>
        <div className="address">
          <img src={mapIcon} alt="Map Icon" className="map-icon" />
          <p>65/2, Block-A, Bagmane Technology Park, Byrasandra Village, C V Raman Nagar, Bangalore - 560 093.</p>
        </div>
      </div>
      <div className="paragraph-container">
        <p className="paragraph">
          We utilize our insight into the pharmaceutical business to ensure that
          the majority of our magnificence items and medicines are results
          driven, with the goal that we can offer brands that are ideal for
          every person. ‘Organization Name’ pharmacy is a warm and well disposed
          place, with experienced specialists giving proficient skincare
          medicines, and magnificence exhortation in a quiet and loosening up
          condition.
        </p>
        <p className="paragraph">
          E-Pharm offers one of a kind blend of pharmacy and magnificence facility
          all over the world with numerous superlative wellbeing and excellent
          medicines. Our services incorporate administering remedies, new drug
          benefits, a gathering and conveyance work, glucose and cholesterol
          checks, a stroll in movement facility, and a huge number of wellbeing
          and excellence medicines and items.
        </p>
        <p className="paragraph">
          Thank you for considering E-Pharm to provide your important medicine
          requirements and logistics needs. Our vision and commitment to our
          customers are to deliver the best quality service and personal attention.
        </p>
      </div>
      <div className="footer">
        <p>&copy; 2024 Online E-Pharmacy. All rights reserved.</p>
      </div>
    </div>

  );
};

export default About;
