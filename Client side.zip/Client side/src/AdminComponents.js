import React from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import Dashboard from './Dashboard';
import Product from './Product';
import About from './About';
import './AdminComponents.css';
import Adminprofile from './Adminprofile';
import FindDoctor from './FindDoctor';
import Login from './Login';
import Diabetes from './components/Products/Diabetes';
import Dentalcare from './components/Products/Dentalcare';
import Depression from './components/Products/Depression';
import Dermatology from './components/Products/Dermatology';
import Bloodpressure from './components/Products/Bloodpressure';
import Trichology from './components/Products/Trichology'
import Orders from './Orders';
import Checkout from './Checkout';
import PaymentPage from './PaymentPage';

const AdminComponents = () => {
  return (
    <div style={{ background: 'url("images/Dashboard.jpg")', backgroundSize: '100% 100%', minHeight: '100vh' }}>

      <Router>
        <div style={{ padding: '10px', color: 'red' }}>
          <ul>
            <li>Online E pharmacy</li>
            <li><NavLink className='link' to="/Dashboard">Dashboard</NavLink></li>
            <li><NavLink className='link' to="/product">Medicines</NavLink></li>
            
            <li><NavLink className='link' to="/FindDoctor">Find Doctors</NavLink></li>
            <li><NavLink className='link' to="/profile">profile</NavLink></li>
            <li><NavLink className='link' to="/About">About</NavLink></li>
            <li><NavLink className='link' to="/login">Logout</NavLink></li>
          </ul>
        </div>
        <Routes>
          <Route path="/Dashboard" element={<Dashboard />} />
          <Route path="/product" element={<Product />} />
          <Route path="/About" element={<About />} />
          <Route path="/FindDoctor" element={<FindDoctor />} />
          <Route path="/profile" element={<Adminprofile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/diabetes" element={<Diabetes />} />
          <Route path="/dentalcare" element={<Dentalcare />} />
          <Route path="/depression" element={<Depression />} />
          <Route path="/dermatology" element={<Dermatology />} />
          <Route path="/bloodpressure" element={<Bloodpressure />} />
          <Route path="/trichology" element={<Trichology />} />
          <Route path="/Orders" element={<Orders />} />
          <Route path="/Checkout" element={<Checkout />} />
          <Route path="/PaymentPage" element={<PaymentPage />} />
          

        </Routes>
      </Router>
    </div>
    
  );
};

export default AdminComponents;
