import axios from 'axios';
import { useState } from 'react';

function Adminprofile() {

    const [cumsArray, setCumsArray] = useState([]);
    const [empId, setEmpId] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [address, setAddress] = useState("");




    function getDataButton_click() {

        let url = "http://localhost:3004/api/register/employee";
        axios.get(url).then((resData) => {
            setCumsArray(resData.data);
        });
    }

    function addDeptButton_click() {

        let deptObj = {};
        deptObj.empId = empId;
        deptObj.name = name;
        deptObj.email = email;
        deptObj.password = password;
        deptObj.address = address;

        let url = "http://localhost:3004/api/register/employee";
        axios.post(url, deptObj).then((resData) => {
            alert(resData.data.status);
            getDataButton_click();
        });


        clearFields();
    }

    function selectDept_click(item) {
        setEmpId(item.empId);
        setName(item.name);
        setEmail(item.email);
        setPassword(item.password);
        setAddress(item.address);

    }


    function updateDeptButton_click() {
        let deptObj = {};
        deptObj.empId = empId;
        deptObj.name = name;
        deptObj.email = email;
        deptObj.password = password;
        deptObj.address = address;
        let url = "http://localhost:3004/api/register/employee";
        axios.put(url, deptObj).then((resData) => {
            alert(resData.data.status);
            clearFields();
            getDataButton_click();
        });

    }

    function deleteDept_click(eno) {

        let flag = window.confirm("Are you sure want to delete?");
        if (flag == false) {
            return;
        }

        let url = "http://localhost:3004/api/register/employee/" + eno;
        axios.delete(url).then((resData) => {
            alert(resData.data.status);
            getDataButton_click();
        });
    }

    function clearFields() {
        setEmpId("");
        setName("");
        setEmail("");
        setPassword("");
        setAddress("");
    }


    let resultArray = cumsArray.map(item => {
        return (

            <div key={item.empId} style={{ marginBottom: '10px' }}>
                <div><strong>Customer ID:</strong> {item.empId}</div>
                <div><strong>Name:</strong> {item.name}</div>
                <div><strong>Email:</strong> {item.email}</div>
                <div><strong>password:</strong> {item.password}</div>
                <div><strong>Address:</strong> {item.address}</div>
                <div>
                    <input
                        type="button"
                        onClick={() => selectDept_click(item)}
                        value="Select Data"
                    />
                </div>
                <div>
                    <a href="javascript:void(0);" onClick={() => deleteDept_click(item.empId)}>
                        <img src="images/delete1.jpg" width="20" />
                    </a>
                </div>
                <hr />
            </div>
        );


    });





    return (
        <div style={{ "border": "2px solid blue", "padding": "20px", "padding-bottom": "15px", "backgroundColor": "lightyellow", "width": "300px", "height": "800px", "float": "right" }}>



            <input type="button" onClick={getDataButton_click} value="Get Profile" />
            <img
                src="images/pic.jpg"
                width="100"
                height="100"
                style={{
                    float: 'right',  // Align the image to the right
                    borderRadius: '50%', // Make the image round-shaped
                    marginRight: '10px' // Add some margin to separate from other content
                }}
                alt=""
            />

            <h3>View Profile</h3>
            <div>
                <div>
                    {/* Display Add New Profile and Edit Profile form elements here */}
                </div>
                <div>
                    {resultArray}
                </div>
            </div>
            <hr />

            <input type="text" placeholder="Customer ID" value={empId} onChange={(e) => setEmpId(e.target.value)} />
            <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
            <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="text" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <input type="text" placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} />
            <hr />
            <input type="button" onClick={updateDeptButton_click} value="Update profile" />
            <input type="button" onClick={addDeptButton_click} value="Add profile" />



            <hr />

        </div>
    );
}

export default Adminprofile;