import axios from 'axios';
import { useState } from 'react';

function AjaxDemo3() {

    const [deptsArray, setDeptsArray] = useState([]);
    const [deptno, setDeptno] = useState("");
    const [dname, setDname] = useState("");
    const [loc, setLoc] = useState("");



    function getDataButton_click() {

        let url = "http://localhost:3004/api/Depts";
        axios.get(url).then((resData) => {
            setDeptsArray(resData.data);
        });
    }



    function addDeptButton_click() {

        let deptObj = {};
        deptObj.Deptno = deptno;
        deptObj.Dname = dname;
        deptObj.Loc = loc;


        let url = "http://localhost:3004/api/Depts";
        axios.post(url, deptObj).then((resData) => {
            alert(resData.data.status);
            getDataButton_click();
        });


        clearFields();
    }

    function clearFields() {
        setDeptno("");
        setDname("");
        setLoc("");
    }

    function deleteDept_click(dno) {

        let flag = window.confirm("Are you sure want to delete?");
        if (flag == false) {
            return;
        }

        let url = "http://localhost:3004/api/Depts/" + dno;
        axios.delete(url).then((resData) => {
            alert(resData.data.status);
            getDataButton_click();
        });
    }

    function selectDept_click(item) {
        setDeptno(item.Deptno);
        setDname(item.Dname);
        setLoc(item.Loc);

    }

    function updateDeptButton_click() {
        let deptObj = {};
        deptObj.Deptno = deptno;
        deptObj.Dname = dname;
        deptObj.Loc = loc;
        let url = "http://localhost:3004/api/Depts";
        axios.put(url, deptObj).then((resData) => {
            alert(resData.data.status);
            clearFields();
            getDataButton_click();
        });

    }


    let resultArray = deptsArray.map(item => {
        return (

            <div key={item.Deptno} style={{ marginBottom: '10px' }}>
                <div><strong>Customer ID:</strong> {item.Deptno}</div>
                <div><strong>Name:</strong> {item.Dname}</div>
                <div><strong>Location:</strong> {item.Loc}</div>
                <div>
                    <a href="javascript:void(0);" onClick={() => deleteDept_click(item.Deptno)}>
                        <img src="images/1.jpg" width="20" />
                    </a>
                </div>
                <div>
                    <input
                        type="button"
                        onClick={() => selectDept_click(item)}
                        value="Select Data"
                    />
                </div>
                <hr />
            </div>
        );


    });





    return (
        <div style={{ "border": "2px solid blue", "padding": "20px", "padding-bottom": "15px", "backgroundColor": "lightyellow", "width": "300px", "height": "600px", "float": "right" }}>



            <input type="button" onClick={getDataButton_click} value="Get Data" />
            <img
                src="images/pic.jpg"
                width="100"
                height="100"
                style={{
                    float: 'right',  // Align the image to the right
                    borderRadius: '50%', // Make the image round-shaped
                    marginRight: '10px' // Add some margin to separate from other content
                }}
                alt=""
            />

            <h3> Profile</h3>
            <div>
                <div>
                    {/* Display Add New Profile and Edit Profile form elements here */}
                </div>
                <div>
                    {resultArray}
                </div>
            </div>
            

            <input type="text" placeholder="Customer Number" value={deptno} onChange={(e) => setDeptno(e.target.value)} />
            <input type="text" placeholder="Customer Name" value={dname} onChange={(e) => setDname(e.target.value)} />
            <input type="text" placeholder="Customer Location" value={loc} onChange={(e) => setLoc(e.target.value)} />
            <hr />


            <input type="button" onClick={addDeptButton_click} value="Add Profile" />
            <input type="button" onClick={updateDeptButton_click} value="Update Profile" />


            <hr />

        </div>
    );
}

export default AjaxDemo3;