import React, { useState } from 'react';
import Login from './Login';
import AdminComponents from './AdminComponents';
import EmployeeComponents from './EmployeeComponents';
import Register from './Register';
import Orders from './Orders';
import Checkout from './Checkout'; // Import the Orders and Checkout components

const App = () => {
  const [userRole, setUserRole] = useState('');
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([
    { id: 1, title: 'Product 1', price: 10.99 },
    { id: 2, title: 'Product 2', price: 20.99 },
    { id: 3, title: 'Product 3', price: 15.99 }
  ]);
  const [currentPage, setCurrentPage] = useState('cart');

 /* const handleAddToCart = (item, quantity) => {
    const updatedCart = [...cart];
    const index = updatedCart.findIndex(cartItem => cartItem.id === item.id);
    if (index !== -1) {
      updatedCart[index].amount += quantity;
      if (updatedCart[index].amount <= 0) {
        updatedCart.splice(index, 1);
      }
    }
    setCart(updatedCart);
  };*/

  const handleCheckout = () => {
    // Logic for checkout process
    // For example, add current cart to orders and clear the cart
    setOrders(prevOrders => [...prevOrders, { id: Date.now(), totalPrice: getTotalPrice() }]);
    setCart([]);
    setCurrentPage('orders');
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.amount, 0);
  };

  return (
    
      <div>
        {userRole === 'admin' ? (
          <AdminComponents />
        ) : userRole === 'employee' ? (
          <EmployeeComponents />
        ) : userRole === 'register' ? (
          <Register />
        ) : (
          <Login setUserRole={setUserRole} />
        )}
      </div>
    
  );
};

export default App;
