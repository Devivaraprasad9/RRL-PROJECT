import React, { useState, useEffect } from 'react';
import './Checkout.css';
import { Link } from 'react-router-dom';

const Checkout = ({ cart }) => {
    const [localStorageCart, setLocalStorageCart] = useState([]);

    useEffect(() => {
        // Retrieve cart from localStorage when component mounts
        const storedCart = JSON.parse(localStorage.getItem('cart'));
        if (storedCart) {
            setLocalStorageCart(storedCart);
        }
    }, []);

    const removeFromCart = (itemToRemove) => {
        const updatedCart = localStorageCart.filter(item => item.id !== itemToRemove.id);
        setLocalStorageCart(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
    };

    const calculateTotalPrice = () => {
        const totalPrice = localStorageCart.reduce((total, item) => total + item.price, 0);
        return totalPrice.toFixed(2);
    };

    return (
        <div>
            <Link to="/product"><button>Back to Products</button></Link>
            <h2>Checkout</h2>
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {localStorageCart.map((item, index) => (
                        <tr key={index}>
                            <td>{item.title}</td>
                            <td>Rs - {item.price}</td>
                            <td><button onClick={() => removeFromCart(item)}>Remove from Cart</button></td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <button onClick={() => alert(`Total Price: Rs - ${calculateTotalPrice()}`)}>Total Price</button>
            <Link to="/PaymentPage"><button>Pay Here</button></Link>
        </div>
    );
};

export default Checkout;
