import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar } from 'recharts';
import './Dashboard.css'; // Assuming you have your CSS styles in a Dashboard.css file

function Dashboard() {
  // Sample data for medicine details, customer visits, sale details, stock availability, services provided per year, and eligible offers
  const medicineData = [
    { name: 'Diabetic', quantity: 360 },
    { name: 'Dermatology', quantity: 458 },
    { name: 'Depression', quantity: 250 },
    { name: 'Blood pressure', quantity: 300 },
  ];

  const customerData = [
    { name: 'Jan-mar', visits: 230 },
    { name: 'Apr-jun', visits: 400},
    { name: 'jul-sep', visits: 780 },
    { name: 'oct-dec', visits: 690 },
  ];

  const saleData = [
    { name: 'jan-mar', amount: 890 },
    { name: 'Apr-jun', amount: 1080 },
    { name: 'jul-sep', amount: 470 },
    { name: 'oct-dec', amount:690 },
  ];

  const stockAvailabilityData = [
    { name: 'Diabetic', quantity: 5900 },
    { name: 'Dermatology', quantity: 8765 },
    { name: 'Depression', quantity: 7685 },
    { name: 'Blood pressure', quantity: 9876 },
  ];

  const servicesProvidedData = [
    { year: '2020', services: 5000 },
    { year: '2021', services: 2800 },
    { year: '2022', services: 3800 },
    { year: '2023', services: 3460 },
  ];

  const eligibleOffersData = [
    { medicine: 'Enalapril', offer: 'Buy 2 Get 1 Free' },
    { medicine: 'perindopril', offer: '20% Off on Next Purchase' },
    { medicine: 'insulin', offer: '10% Cashback' },
    { medicine: 'Anti Androgens', offer: 'Free Home Delivery' },
  ];

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Dashboard</h1>
      <div className="dashboard">
        {/* Medicine Details */}
        <div className="chart-container">
          <h2>Medicine Details</h2>
          <BarChart width={400} height={300} data={medicineData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="quantity" fill="#8884d8" />
          </BarChart>
        </div>

        {/* Customer Visits */}
        <div className="chart-container">
          <h2>Customer Visits</h2>
          <LineChart width={400} height={300} data={customerData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="visits" stroke="#82ca9d" />
          </LineChart>
        </div>

        {/* Sale Details */}
        <div className="chart-container">
          <h2>Sale Details</h2>
          <BarChart width={400} height={300} data={saleData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="amount" fill="#ffc658" />
          </BarChart>
        </div>

        {/* Stock Availability */}
        <div className="chart-container">
          <h2>Stock Availability</h2>
          <LineChart width={400} height={300} data={stockAvailabilityData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="quantity" stroke="#ff7f0e" />
          </LineChart>
        </div>

        {/* Services Provided Per Year */}
        <div className="chart-container">
          <h2>Services Provided Per Year</h2>
          <BarChart width={400} height={300} data={servicesProvidedData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="services" fill="#ff5733" />
          </BarChart>
        </div>

        {/* Customer Visits */}
        <div className="chart-container">
          <h2>Lab Reports </h2>
          <LineChart width={400} height={300} data={customerData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="visits" stroke="#82ca9d" />
          </LineChart>
        </div>

        {/* Eligible Offers on Medicines */}
        <div className="offers-container">
          <h2>Eligible Offers on Medicines</h2>
          <table>
            <thead>
              <tr>
                <th>Medicine</th>
                <th>Offer</th>
              </tr>
            </thead>
            <tbody>
              {eligibleOffersData.map((offer, index) => (
                <tr key={index}>
                  <td>{offer.medicine}</td>
                  <td>{offer.offer}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;