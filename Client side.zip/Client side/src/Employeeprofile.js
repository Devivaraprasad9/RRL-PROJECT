import axios from 'axios';
import { useState } from 'react';

function Employeeprofile() {

    const [deptsArray, setDeptsArray] = useState([]);
    const [empId, setEmpId] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [address, setAddress] = useState("");




    function getDataButton_click() {

        let url = "http://localhost:3004/api/register/employee";
        axios.get(url).then((resData) => {
            setDeptsArray(resData.data);
        });
    }

    function selectDept_click(item) {
        setEmpId(item.empId);
        setName(item.name);
        setEmail(item.email);
        setPassword(item.password);
        setAddress(item.address);

    }


    function updateDeptButton_click() {
        let deptObj = {};
        deptObj.empId = empId;
        deptObj.name = name;
        deptObj.email = email;
        deptObj.password = password;
        deptObj.address = address;
        let url = "http://localhost:3004/api/register/employee";
        axios.put(url, deptObj).then((resData) => {
            alert(resData.data.status);

            getDataButton_click();
        });

    }

    let resultArray = deptsArray.map(item => {
        return (

            <div key={item.empId} style={{ marginBottom: '10px' }}>
                <div><strong>Customer ID:</strong> {item.empId}</div>
                <div><strong>Name:</strong> {item.name}</div>
                <div><strong>Email:</strong> {item.email}</div>
                <div><strong>password:</strong> {item.password}</div>
                <div><strong>Address:</strong> {item.address}</div>
                <div>
                    <input
                        type="button"
                        onClick={() => selectDept_click(item)}
                        value="Select Data"
                    />
                </div>
                <hr />
            </div>
        );


    });





    return (
        <div style={{ "border": "2px solid blue", "padding": "20px", "padding-bottom": "15px", "backgroundColor": "lightyellow", "width": "300px", "height": "800px", "float": "right" }}>



            <input type="button" onClick={getDataButton_click} value="Get Data" />
            <img
                src="images/pic.jpg"
                width="100"
                height="100"
                style={{
                    float: 'right',  // Align the image to the right
                    borderRadius: '50%', // Make the image round-shaped
                    marginRight: '10px' // Add some margin to separate from other content
                }}
                alt=""
            />

            <h3> Profile</h3>
            <div>
                <div>
                    {/* Display Add New Profile and Edit Profile form elements here */}
                </div>
                <div>
                    {resultArray}
                </div>
            </div>
            <hr />

            <input type="text" placeholder="Customer ID" value={empId} onChange={(e) => setEmpId(e.target.value)} />
            <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
            <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="text" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <input type="text" placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} />
            <hr />

            <input type="button" onClick={updateDeptButton_click} value="Update Data" />



            <hr />

        </div>
    );
}

export default Employeeprofile;