import React, { useState } from 'react';
import './FindDoctor.css'

const FindDoctor = () => {
  // State variables for form inputs
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [selectedSpeciality, setSelectedSpeciality] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');

  // Dummy data for demonstration purposes
  const availableSpecialities = ['Cardiologist', 'Dermatologist', 'Orthopedic', 'Pediatrician'];

  const availableDoctors = {
    Cardiologist: ['Dr. Smith', 'Dr. Johnson'],
    Dermatologist: ['Dr. Brown', 'Dr. Davis'],
    Orthopedic: ['Dr. Miller', 'Dr. Wilson'],
    Pediatrician: ['Dr. Jones', 'Dr. Taylor'],
  };

  // Handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();

    // Check if all fields are filled
    if (!location || !date || !selectedSpeciality || !selectedDoctor) {
      alert('Please fill in all mandatory fields');
      return;
    }

    // Perform actions with the form data (e.g., send to backend, filter results)
    // You can log the data for now
    console.log({ location, date, selectedSpeciality, selectedDoctor });

    // Display a popup message
    const confirmationMessage = `Your appointment is booked on ${date}`;
    alert(confirmationMessage);

    // Optionally, you can reset the form fields after submission
    setLocation('');
    setDate('');
    setSelectedSpeciality('');
    setSelectedDoctor('');
  };

  // Handle speciality change to update the available doctors
  const handleSpecialityChange = (speciality) => {
    setSelectedSpeciality(speciality);
    // Reset selected doctor when changing speciality
    setSelectedDoctor('');
  };

  return (
    <div className="find-doctor-container">
      <header>
        <h1>Find Doctors</h1>
      </header>

      <banner>
        <img src=".\images\banner.jpg" alt="Banner Image" />
      </banner>

      <main>
        <form onSubmit={handleSubmit}>
          {/* Location */}
          <label htmlFor="location" >Preferred Location</label>
          <input
            type="text"
            id="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Enter Location"
            required
          />

          {/* Date */}
          <label htmlFor="date">Select Date</label>
          <input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            min={new Date().toISOString().split('T')[0]} // Set min attribute to today's date
            required
          />

          {/* Speciality Dropdown */}
          <label htmlFor="speciality">Select Speciality</label>
          <select
            id="speciality"
            value={selectedSpeciality}
            onChange={(e) => handleSpecialityChange(e.target.value)}
            required
          >
            <option value="">Select a Speciality</option>
            {availableSpecialities.map((speciality, index) => (
              <option key={index} value={speciality}>
                {speciality}
              </option>
            ))}
          </select>

          {/* Doctor Dropdown */}
          <label htmlFor="doctors">Select Doctor</label>
          <select
            id="doctors"
            value={selectedDoctor}
            onChange={(e) => setSelectedDoctor(e.target.value)}
            required
          >
            <option value="">Select a Doctor</option>
            {availableDoctors[selectedSpeciality]?.map((doctor, index) => (
              <option key={index} value={doctor}>
                {doctor}
              </option>
            ))}
          </select>

          {/* Submit Button */}
          {/* Submit Button */}
          <button type="submit" className="btn btn-success">Submit</button>

        </form>
      </main>

      {/* Footer Code */}
      <footer className="footer-distributed">
        <div className="footer-left">
          <h3>Pharma<span>Cy</span></h3>
          <p className="footer-links">
            <a href="#">About</a>
            |
            <a href="#">Contact</a>
            |
            <a href="#">Blog</a>
          </p>
          <p className="footer-company-name">Copyright © 2024 <strong>Pharma</strong> All rights reserved</p>
        </div>
        <div className="footer-center">
          <div>
            <img src="./images/mapp.jpg" width="15" />
            <p>India
            </p>
          </div>
          <div>
            <img src="./images/phon.jpg" width="15" />
            <p>+91 9048421563</p>
          </div>
          <div>
            <img src="./images/e.jpg" width="15" />
            <p><a href="pharma@gmail.com">pharma@gmail.com</a></p>
          </div>
        </div>

        <div className="footer-right">
          <p className="footer-company-about">
            <span>About the Pharmacy</span>
            <strong>Pharma</strong>, As pioneers in the healthcare segment, we understand the importance of trust. And that is why, over the years, we worked on building that trust.

          </p>
          <div className="footer-icons">
            <a href="#"><img src="./images/face.jpg" width="30" /></a>
            <a href="#"><img src="./images/insta.jpg" width="30" /></a>
            <a href="#"><img src="./images/l.jpg" width="30" /></a>
            <a href="#"><img src="./images/twitter.jpg" width="30" /></a>


          </div>
        </div>

      </footer>
    </div>
  );
};

export default FindDoctor;
