
import "./HomePage.css";
function HomePage(){
    return(
        <>
       <div style={{ backgroundColor: 'white' }}>
        <img src="images/download.jpg" width="1500px" height="250px"/>
       </div>
      
        <div className="flex-images">
            <div className="card1">
                <img src="images/1.png"/>
                <p>Pharmacy</p>
            </div>
            <div className="card1">
                <img src="images/2.png" />
                <p>Dignostics</p>
            </div>
            <div className="card1">
                <img src="images/3.png" />
                <p>Doctors</p>
            </div>
            <div className="card1">
                <img src="images/4.jpg" />
                <p>factory </p>
            </div>
            <div className="card1">
                <img src="images/5.jpg" />
                <p>factory </p>
            </div>
            <div className="card1">
                <img src="images/6.jpg" />
                <p>factory </p>
            </div>
            <div className="card1"s>
                <img src="images/7.jpg" />
                <p>factory </p>
            </div>
        </div>
        <p align-item="center">We have the products</p>
        <div className="flex-images">
       
            <div className="card2">
                <img src="images/11.png"/>
            </div>
            <div className="card2">
                <img src="images/12.png"/>
            </div>
            <div className="card2"> 
                <img src="images/13.jpg"/>
            </div>
            <div className="card2">
                <img src="images/14.jpg"/>
            </div>
              
        </div>
        <div className="card3">
            <p>Information You can Use for a</p>
            <h2>HEALTHY LIFE</h2>
            <p>Natural Remedies for Common Cold</p>
            <p>Whether it’s a runny nose, sore throat, or persistent cough, a common cold can be quite irritating. Trying to focus on our work with a stuffy nose, scratchy throat, and non-stop sneezing becomes challenging.....</p>
        </div><hr/>
        <div className="card4">
            <p>6 Reasons for you to Shop from US:</p>
<ul>
<li>Authentic medicines: Be 100% assured of receiving genuine medicines</li>
<li>Monthly provisions: One stop store for both medicines as well as monthly provisions (kiraana)</li>
<li>Quick to-door deliveries: We ensure the delivery of well-packaged products to your doorstep at quick timelines.</li>
<li>Pocket-friendly: Our range of discounts, offers and deals will allow you to go economical everyday, everytime. We recommend you to explore Payback Special Sale, our special saving scheme.</li>
<li>Customer-friendly: Order from the comfort of your sofa with our easy browsing and smooth billing procedure. Our hassle-free Upload option allows you to seamlessly upload your prescription online and have your medicines delivered to you!</li>
<li>Track and Re-Order: Conveniently refer to all your previous bills and orders which will allow you to re-order with a single click.</li>
<li>Also, for those of you who prefer offline shopping, locate your nearest store and get going!</li></ul>
        </div>
        <div class="foot-panel4">
            <div class="pages">
                <a>Conditons of Use & Sale</a>
                <a>Privacy Notice</a>
                <a>Your Ads Privacy Choices</a>
            </div>
            <div class="copyright">
                © 1996-2023, Amazon.com, Inc. or its affiliates
            </div>
        </div>
        </>
    )

}

export default HomePage;