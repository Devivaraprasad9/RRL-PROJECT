import React, { useState } from 'react';
import axios from 'axios';
import './Login.css';


const Login = ({ setUserRole }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleAdminLogin = () => {
    axios.post('http://localhost:3004/api/login/admin', { email, password })
      .then(response => {
        const { token, role } = response.data;
        localStorage.setItem('token', token);
        setUserRole(role);
      })

      .catch(error => {
        console.error('Login error:', error);
      });
  };

  const handleEmpLogin = () => {
    axios.post('http://localhost:3004/api/login/employee', { email, password })
      .then(response => {
        const { token, role } = response.data;
        localStorage.setItem('token', token);
        setUserRole(role);
      })
      .catch(error => {
        console.error('Login error:', error);
      });
  };
  function handleRegister() {
    setUserRole('register')
  }

  return (
    <div className='main' style={{ backgroundImage: 'url("images/login1.jpg")', backgroundSize: 'cover', height: '100vh' }}>

      <button className='signin-btn' onClick={handleAdminLogin} style={{ position: 'absolute', top: '10px', right: '10px' }}>
        <span style={{ marginRight: '5px' }}>👤</span> {/* Unicode character for user symbol */} </button>

      <div className='container' align='center'>

        <p></p>
        <h1>Login</h1>
        <fieldset >
          <label>Username :</label> <input type="text" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Example@gmail.com" required /><br />
          <label>Password :</label> <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required /><br />
          <button className='signin-btn' onClick={handleEmpLogin}>Login</button>|
          <button className='signin-btn' onClick={handleRegister}>Register</button>
        </fieldset>

      </div>

    </div>
  );
};

export default Login;
