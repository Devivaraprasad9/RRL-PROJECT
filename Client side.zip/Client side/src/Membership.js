import React, { useState } from 'react';
import './MembershipForm.css';

const Membership = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phoneNumber: '',
    address: '',
    prescriptionFile: null,
    membershipPlan: 'monthly',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData({ ...formData, prescriptionFile: file });
  };

  const handleSubmit = () => {
    const confirmSubmission = window.confirm('Are you sure you want to submit?');
    if (confirmSubmission) {
      // Handle form submission
    }
  };

  return (
    <div className="container">
      <h1>Membership Form</h1>
      <form onSubmit={handleSubmit}>
        <table>
          <tbody>
            <tr>
              <td>Name:</td>
              <td><input type="text" name="name" value={formData.name} onChange={handleChange} /></td>
            </tr>
            <tr>
              <td>Email:</td>
              <td><input type="email" name="email" value={formData.email} onChange={handleChange} /></td>
            </tr>
            <tr>
              <td>Password:</td>
              <td><input type="password" name="password" value={formData.password} onChange={handleChange} /></td>
            </tr>
            <tr>
              <td>Phone Number:</td>
              <td><input type="tel" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} /></td>
            </tr>
            <tr>
              <td>Address:</td>
              <td><input type="text" name="address" value={formData.address} onChange={handleChange} /></td>
            </tr>
            <tr>
              <td>Prescription Upload:</td>
              <td><input type="file" name="prescriptionFile" onChange={handleFileChange} /></td>
            </tr>
            <tr>
              <td>Membership Plan:</td>
              <td>
                <select name="membershipPlan" value={formData.membershipPlan} onChange={handleChange}>
                <option value="select">Select</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                </select>
              </td>
            </tr>
          </tbody>
        </table>
        <button type="submit">Submit</button>
      </form>
      <div className="membership-benefits">
        <h2>Membership Benefits</h2>
        <div className="benefit-card">
          <h3>Free Deliveries</h3>
          <p>Enjoy free deliveries on all orders.</p>
        </div>
        <div className="benefit-card">
          <h3>Extra Cashback</h3>
          <p>Get extra cashback on every order.</p>
        </div>
        <div className="benefit-card">
          <h3>Exclusive Discounts</h3>
          <p>Access exclusive discounts as a member.</p>
        </div>
      </div>
      <h2>FAQ</h2>
      <div className="faq">
        <h3>Ordering Process:</h3>
        <ul>
          <li><strong>How do I place an order?</strong> <br /> You can easily place an order by browsing our website, selecting the desired products, and following the checkout process.</li>
          <li><strong>Can I order medications without a prescription?</strong> <br /> Certain medications may require a valid prescription from a healthcare provider. However, we also offer a wide range of over-the-counter products that do not require a prescription.</li>
          <li><strong>What payment methods do you accept?</strong> <br /> We accept various payment methods, including credit/debit cards, PayPal, and other secure online payment options.</li>
        </ul>
      </div>
      
    
    </div>
  );
};

export default Membership;
