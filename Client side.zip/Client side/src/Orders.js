import React, { useState  } from 'react';
import { Link } from 'react-router-dom';
import './Orders.css';

const Orders = ({  }) => {
    const [cart, setCart] = useState([]);

    const orders = [
        { id: 1, category: 'Diabetes', medicines: [
            { id: 1, title: 'Insulin', price: 700 },
            { id: 2, title: 'Glycomate', price: 150 },
            { id: 3, title: 'Gliclazide', price: 350 }
        ]},
        { id: 2, category: 'Dental Care', medicines: [
            { id: 1, title: 'Ambesol', price: 60 },
            { id: 2, title: 'Xylocaine', price: 150 },
            { id: 3, title: 'Chloraseptic', price: 300 }
        ]},
        { id: 3, category: 'Blood Pressure', medicines: [
            { id: 1, title: 'Enalapril', price: 100 },
            { id: 2, title: 'Lisinopril', price: 260 },
            { id: 3, title: 'Perindopril', price: 390 }
        ]},
        { id: 4, category: 'Depression', medicines: [
            { id: 1, title: 'Dosulepin', price: 200 },
            { id: 2, title: 'Duloxetine', price: 350 },
            { id: 3, title: 'Doxepin', price: 700 }
        ]},
        { id: 5, category: 'Dermatology', medicines: [
            { id: 1, title: 'Acetretin', price: 700 },
            { id: 2, title: 'Antiandrogens', price: 1200 },
            { id: 3, title: 'Antimalarials', price: 1000 }
        ]},
        { id: 6, category: 'Trichology', medicines: [
            { id: 1, title: 'Beer shampoo', price: 100 },
            { id: 2, title: 'Foligrowth', price: 150 },
            { id: 3, title: 'Rogaine', price: 300 }
        ]}
    ];

    const addToCart = (item, quantity) => {
        const newItem = { ...item, quantity };
        setCart(prevCart => [...prevCart, newItem]);
        alert(`${item.title} has been added to the cart.`);
        localStorage.setItem('cart', JSON.stringify([...cart, newItem]));
        
    };

    const calculateTotalPrice = () => {
        const totalPrice = cart.reduce((total, item) => total + item.price * item.quantity, 0);
        return totalPrice.toFixed(2);
    };

    return (
        <div>
            <Link to="/product"><button>Back to Products</button></Link>
            <h2>Orders</h2>
            {orders.map(order => (
                <div key={order.id}>
                    <h3>{order.category}</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Medicine</th>
                                <th>Price</th>
                                
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {order.medicines.map(medicine => (
                                <tr key={medicine.id}>
                                    <td>{medicine.title}</td>
                                    <td>Rs - {medicine.price}</td>
                                   
                                    <td>
                                        <button onClick={() => addToCart(medicine, 1)}>Add to Cart</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ))}
            <button onClick={() => alert(`Total Price: Rs - ${calculateTotalPrice()}`)}>Total Price</button>
        </div>
    );
};

export default Orders;
