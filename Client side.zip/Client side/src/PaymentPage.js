import React, { useState } from 'react';
import './PaymentPage.css';

const PaymentPage = () => {
    const [paymentInfo, setPaymentInfo] = useState({
        cardNumber: '',
        cardholderName: '',
        expirationDate: '',
        cvv: ''
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setPaymentInfo({ ...paymentInfo, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Here you can implement logic to handle the payment submission
        console.log('Payment information submitted:', paymentInfo);
        // You can also reset the form after submission
        setPaymentInfo({
            cardNumber: '',
            cardholderName: '',
            expirationDate: '',
            cvv: ''
        });
    };

    const handleDownloadPDF = () => {
        window.open("https://drive.google.com/file/d/1TQ0EesHer7Ly0ZBM7L13JIBlR4tbTwL8/view?usp=drive_link");
        alert('Bill Downloaded');
    };

    return (
        <div>
            <button onClick={handleDownloadPDF} style={{ float: 'right' }}>Download Bill</button>

            <div className="container">

                <h2 className="heading">Enter Payment Information</h2>
                <form onSubmit={handleSubmit} className="form">
                    <div className="inputGroup">
                        <label htmlFor="cardNumber" className="label">Card Number:</label>
                        <input
                            type="text"
                            id="cardNumber"
                            name="cardNumber"
                            value={paymentInfo.cardNumber}
                            onChange={handleInputChange}
                            className="input"
                            placeholder="Enter your card number"
                            required
                        />
                    </div>
                    <div className="inputGroup">
                        <label htmlFor="cardholderName" className="label">Cardholder Name:</label>
                        <input
                            type="text"
                            id="cardholderName"
                            name="cardholderName"
                            value={paymentInfo.cardholderName}
                            onChange={handleInputChange}
                            className="input"
                            placeholder="Enter cardholder name"
                            required
                        />
                    </div>
                    <div className="inputGroup">
                        <label htmlFor="expirationDate" className="label">Expiration Date:</label>
                        <input
                            type="text"
                            id="expirationDate"
                            name="expirationDate"
                            value={paymentInfo.expirationDate}
                            onChange={handleInputChange}
                            className="input"
                            placeholder="MM/YYYY"
                            required
                        />
                    </div>
                    <div className="inputGroup">
                        <label htmlFor="cvv" className="label">CVV:</label>
                        <input
                            type="text"
                            id="cvv"
                            name="cvv"
                            value={paymentInfo.cvv}
                            onChange={handleInputChange}
                            className="input"
                            placeholder="Enter CVV"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        className="submitButton"
                        onClick={() => {
                            alert("Order booked");
                        }}
                    >
                        Submit Payment
                    </button>
                </form>
            </div>
        </div>
    );
};

export default PaymentPage;
