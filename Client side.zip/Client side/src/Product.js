import React from 'react';
import { Link } from 'react-router-dom';
import './Product.css'; // Import your CSS file


const Product = () => {
  return (
    <div>
      <div>
        {/* Navigation buttons */}
        <Link to="/orders">
          <button>medicines</button>
        </Link>
        <Link to="/checkout">
        <div style={{ position: 'fixed', top: '40px', right: '10px' }}>
          <button>Cart</button>
          </div>
        </Link>
      </div>
    
      <div id="container">
        <div className="row">
          <div className="column">
            <div className="product">
              <img src="/images/Diabetic.jpg" alt="Product 1" />
              <div className="product-info">
                <h2>Diabetes</h2>
                <p>Control Blood sugar levels</p>
              </div>
              <Link to="/Diabetes"><button>List medicines</button></Link>
            </div>
          </div>
          <div className="column">
            <div className="product">
              <img src="/images/Dental.jpg" alt="Product 2" />
              <div className="product-info">
                <h2>Dental Care</h2>
                <p>Dental hygiene</p>
              </div>
              <Link to="/Dentalcare"><button>List medicines</button></Link>
            </div>
          </div>
          <div className="column">
            <div className="product">
              <img src="/images/Depression.jpg" alt="Product 3" />
              <div className="product-info">
                <h2>Depression</h2>
                <p>Rid of anxiety</p>
              </div>
              <Link to="/Depression"><button>List medicines</button></Link>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="column">
            <div className="product">
              <img src="/images/Dermatology.jpg" alt="Product 4" />
              <div className="product-info">
                <h2>Dermatology</h2>
                <p>Skin Care</p>
              </div>
              <Link to="/Dermatology"><button>List medicines</button></Link>
            </div>
          </div>
          <div className="column">
            <div className="product">
              <img src="/images/Blood_pressure.jpg" alt="Product 5" />
              <div className="product-info">
                <h2>Blood Pressure</h2>
                <p>Control Blood Pressure</p>
              </div>
              <Link to="/Bloodpressure"><button>List medicines</button></Link>
            </div>
          </div>
          <div className="column">
            <div className="product">
              <img src="/images/hair_care.jpg" alt="Product 6" />
              <div className="product-info">
                <h2>Trichology</h2>
                <p>Hair Care</p>
              </div>
              <Link to="/Trichology"><button>List medicines</button></Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Product;