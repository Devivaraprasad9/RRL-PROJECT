import React, { useState } from "react";
import axios from 'axios';
import './Register.css';



function Register() {
  const [empId, setEmpId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const [securityQuestion, setSecurityQuestion] = useState('');
  const [password, setPassword] = useState('');

  const [address, setAddress] = useState('');



  function handleRegistration() {
    let empObj = {};
    empObj.empId = parseInt(empId);
    empObj.name = name;
    empObj.email = email;

    empObj.securityQuestion = securityQuestion;
    empObj.password = password;

    empObj.address = address;

    axios.post('http://localhost:3004/api/register/employee', empObj)
      .then((resData) => {
        alert(resData.data.status);
        setEmpId('');
        setName('');
        setEmail('');

        setSecurityQuestion('');
        setPassword('');

        setAddress('');
      });
  }



  return (
    <div align='center' className="registration-container" style={{ backgroundImage: 'url("images/regis1.jpg")', backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center center', minHeight: '100vh' }}>
      <h2>Register Here</h2>
      <fieldset className="field" align='left' style={{ border: '1px solid white', width: '30%', padding: '20px', color: 'black' }}>
        <form onSubmit={handleRegistration}>

        <label > Name:</label><br />
          <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter your Full name" /><br />

          <label>Number:</label><br />
          <input type="number" id="empId" value={empId} onChange={(e) => setEmpId(e.target.value)} placeholder="Phone Number" /><br />

          <label>Email:</label><br />
          <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Example@gmail.com" /><br />




          <label>What is your surname Name ? </label><br />
          <input type="text" id="securityQuestion" value={securityQuestion} onChange={(e) => setSecurityQuestion(e.target.value)} placeholder="Nick name" /><br />


          <label >Password:</label><br />
          <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Ser your Password" /><br />




          <label >Address:</label><br />
          <input type="text" id="address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="enter your address" /><br />

          <button className='btn' style={{backgroundColor: 'green', color: 'white'}} type="submit">Register</button> | <button className='register-btn' style={{backgroundColor: 'blue', color: 'white'}} type="submit"><a href='/'>Login</a></button>
        </form>
      </fieldset>


    </div>
  )
}

export default Register;