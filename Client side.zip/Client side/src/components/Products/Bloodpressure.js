import React from 'react';
import { Link } from 'react-router-dom';
import './Bloodpressure.css'; // Importing CSS file for styling

const Bloodpressure = () => {
  return (
    <div className="container">
      {/* Back Button */}
      <Link to="/product"><button>Back to Products</button></Link>

      {/* Medicines for Bloodpressure */}
      <h2 className="medicine-heading">Medicines for Blood pressure</h2>
      <table className="medicine-table">
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Enalapril</td>
            <td>Rs.100/-</td>
          </tr>
          <tr>
            <td>Lisinopril</td>
            <td>Rs.260/-</td>
          </tr>
          <tr>
            <td>Perindopril</td>
            <td>Rs.390/-</td>
          </tr>
          <tr>
            <td>Lopressor</td>
            <td>Rs.500/-</td>
          </tr>
          <tr>
            <td>Zestril</td>
            <td>Rs.100/-</td>
          </tr>
          <tr>
            <td>Captopril</td>
            <td>Rs.200/-</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Bloodpressure;
