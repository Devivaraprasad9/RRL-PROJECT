import React from 'react';
import { Link } from 'react-router-dom';
import './Dentalcare.css'; // Importing CSS file for styling

const Dentalcare = () => {
  return (
    <div className="container">
      {/* Back Button */}
      <Link to="/product"><button>Back to Products</button></Link>

      {/* Medicines for Dentalcare */}
      <h2 className="medicine-heading">Medicines for Dental care</h2>
      <table className="medicine-table">
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Ambesol</td>
            <td>Rs.60/-</td>
          </tr>
          <tr>
            <td>Xylocaine</td>
            <td>Rs.150/-</td>
          </tr>
          <tr>
            <td>Chloraseptic</td>
            <td>Rs.300/-</td>
          </tr>
          <tr>
            <td>Doxycycline</td>
            <td>Rs.250/-</td>
          </tr>
          <tr>
            <td>Amoxicillin</td>
            <td>Rs.500/-</td>
          </tr>
          <tr>
            <td>Acetaminophen</td>
            <td>Rs.800/-</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Dentalcare;
