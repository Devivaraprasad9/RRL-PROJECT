import React from 'react';
import { Link } from 'react-router-dom';
import './Depression.css'; // Importing CSS file for styling

const Depression = () => {
  return (
    <div className="container">
      {/* Back Button */}
      <Link to="/product"><button>Back to Products</button></Link>

      {/* Medicines for Depression */}
      <h2 className="medicine-heading">Medicines for Depression</h2>
      <table className="medicine-table">
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Dosulepin</td>
            <td>Rs.200/-</td>
          </tr>
          <tr>
            <td>Duloxetine</td>
            <td>Rs.350/-</td>
          </tr>
          <tr>
            <td>Doxepin</td>
            <td>Rs.700/-</td>
          </tr>
          <tr>
            <td>Escitalopram</td>
            <td>Rs.300/-</td>
          </tr>
          <tr>
            <td>Agomelatine</td>
            <td>Rs.600/-</td>
          </tr>
          <tr>
            <td>Citalopram</td>
            <td>Rs.290/-</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Depression;
