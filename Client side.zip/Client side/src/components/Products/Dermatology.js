import React from 'react';
import { Link } from 'react-router-dom';
import './Dermatology.css'; // Importing CSS file for styling

const Dermatology = () => {
  return (
    <div className="container">
      {/* Back Button */}
      <Link to="/product"><button>Back to Products</button></Link>

      {/* Medicines for Dermatology */}
      <h2 className="medicine-heading">Medicines for Dermatology</h2>
      <table className="medicine-table">
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Acetretin</td>
            <td>Rs.700/-</td>
          </tr>
          <tr>
            <td>Antiandrogens</td>
            <td>Rs.1200/-</td>
          </tr>
          <tr>
            <td>Antimalarials</td>
            <td>Rs.1000/-</td>
          </tr>
          <tr>
            <td>Antibiotics</td>
            <td>Rs.620/-</td>
          </tr>
          <tr>
            <td>Azvrin 500 mg</td>
            <td>Rs.200/-</td>
          </tr>
          <tr>
            <td>Amoxil</td>
            <td>Rs.500/-</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Dermatology;
