import React from 'react';
import { Link } from 'react-router-dom';
import './Diabetes.css'; // Importing CSS file for styling

const Diabetes = () => {
  return (
    <div className="container">
      {/* Back Button */}
      <Link to="/product"><button>Back to Products</button></Link>

      {/* Medicines for Diabetes */}
      <h2 className="medicine-heading">Medicines for Diabetes</h2>
      <table className="medicine-table">
        <thead>
          <tr>
            <th>Medicines</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Insulin</td>
            <td>Rs.700/-</td>
          </tr>
          <tr>
            <td>Glycomate GP2</td>
            <td>Rs.150/-</td>
          </tr>
          <tr>
            <td>Gliclazide</td>
            <td>Rs.350/-</td>
          </tr>
          <tr>
            <td>Empagliflozin</td>
            <td>Rs.500/-</td>
          </tr>
          <tr>
            <td>Canagliflozin</td>
            <td>Rs.210/-</td>
          </tr>
          <tr>
            <td>Pioglitazone</td>
            <td>Rs.900/-</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Diabetes;
