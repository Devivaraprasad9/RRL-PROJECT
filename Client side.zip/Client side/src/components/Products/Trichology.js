import React from 'react';
import { Link } from 'react-router-dom';
import './Trichology.css'; // Importing CSS file for styling

const Trichology = () => {
  return (
    <div className="container">
      {/* Back Button */}
      <Link to="/product"><button>Back to Products</button></Link>

      {/* Medicines for Diabetes */}
      <h2 className="medicine-heading">Medicines for Hair Care</h2>
      <table className="medicine-table">
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Beer shampoo</td>
            <td>Rs.100/-</td>
          </tr>
          <tr>
            <td>Foligrowth</td>
            <td>Rs.150/-</td>
          </tr>
          <tr>
            <td>Rogaine</td>
            <td>Rs.300/-</td>
          </tr>
          <tr>
            <td>Finasteride</td>
            <td>Rs.100/-</td>
          </tr>
          <tr>
            <td>Minoxidil</td>
            <td>Rs.800/-</td>
          </tr>
          <tr>
            <td>Nutrova Shampoo</td>
            <td>Rs.500/-</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Trichology;
