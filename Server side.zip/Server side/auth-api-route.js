const express = require("express");
const AdminsModel = require('./models/auth-model');
const EmployeesModel = require('./models/emp-model');
const router = express.Router();


router.post('/login/admin', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await AdminsModel.findOne({ email, password });
    if (user) {
      res.json({ token:'admin',role:'admin' });
    } else {
      res.json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

router.post('/login/employee', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await EmployeesModel.findOne({ email, password });
    if (user) {
      res.json({ token:'employee',role:'employee' });
    } else {
      res.json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

router.post('/register/employee',  async  function (req,res)
{ 
      var empObj  = new  EmployeesModel({ 
              empId : parseInt(req.body.empId),	
              name  :  req.body.name,
              email   : req.body.email,
              category  : req.body.category,
              securityQuestion   : req.body.securityQuestion,
              password   : req.body.password,
              salary   : req.body.salary,
              address   : req.body.address,
               });

      // Logic to insert new dept in database
       await  empObj.save(); 
  
  var result = {};
  result.status  = "Record inserted in Database";
  console.log("[Create] - Record inserted in Database");
  res.send(result);           
});

module.exports = router;