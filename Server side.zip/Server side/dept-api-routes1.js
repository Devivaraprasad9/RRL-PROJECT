const express = require("express");
const EmployeesModel = require('./models/emp-model');
const router = express.Router();

// Read All
router.get("/register/employee", async function (req, res) {

    let result = await EmployeesModel.find({}, { "_id": 0 });

    try {
        console.log("[Read All] - No. of  items get from database : " + result.length);
        res.send(result);
    }
    catch (error) {
        // sending error details to client
        res.status(500).send(error);
    }
});

// Read Single
router.get("/register/employee/:id", async function(req, res)
{
    var eno =  req.params.id;   	    
    let result  =  await EmployeesModel.findOne({ empId: eno}, {"_id":0});         
    console.log("[Read Single] - " + JSON.stringify(result));
    res.send(result);     
});
//create
router.post('/register/employee', async function (req, res) {
    var empObj = new EmployeesModel({
        empId: parseInt(req.body.empId),
        name: req.body.name,
        email: req.body.email,
        category: req.body.category,
        securityQuestion: req.body.securityQuestion,
        password: req.body.password,
        salary: req.body.salary,
        address: req.body.address,
    });

    // Logic to insert new dept in database
    await empObj.save();

    var result = {};
    result.status = "Record inserted in Database";
    console.log("[Create] - Record inserted in Database");
    res.send(result);
});

// Update
router.put('/register/employee', async function (req, res) {
    try {
        var empObj = {
            empId: parseInt(req.body.empId),
            name: req.body.name,
            email: req.body.email,
            category: req.body.category,
            securityQuestion: req.body.securityQuestion,
            password: req.body.password,
            salary: req.body.salary,
            address: req.body.address,
        };

        // Logic to update employee record in database
        let result = await EmployeesModel.findOneAndUpdate({ empId: empObj.empId }, { $set: empObj }, { new: true });

        var response = {};
        response.status = "Record updated in Database";
        console.log("[Update] - Record updated in Database");
        res.send(response);
    } catch (error) {
        console.error("[Update] - Error:", error);
        res.status(500).send({ error: "Internal Server Error" });
    }
});
	

// Delete
router.delete('/register/employee/:id',async function (req,res)
{  
    var eno =  req.params.id;   
    let Result  =  await  EmployeesModel.findOneAndDelete({ empId: eno}); 

    var result = {};
    result.status  = "Record deleted from Database";
    console.log("[Delete] - Record deleted from Database");
    res.send(result);
       
});



module.exports = router;